create definer = kanshan@`%` view departmenttransferview as
select `pms`.`departmenttransfer`.`sid`     AS `sid`,
       `pms`.`departmenttransfer`.`did1`    AS `did1`,
       `pms`.`departmenttransfer`.`did2`    AS `did2`,
       `pms`.`departmenttransfer`.`tdate`   AS `tdate`,
       `pms`.`departmenttransfer`.`reason`  AS `reason`,
       `pms`.`departmenttransfer`.`remarks` AS `remarks`,
       `pms`.`departmenttransfer`.`type`    AS `type`,
       `pms`.`staff`.`name`                 AS `name`,
       `pms`.`transfer2`.`typename`         AS `typename`,
       `pms`.`departmenttransfer`.`pf`      AS `pf`
from ((`pms`.`departmenttransfer` join `pms`.`staff` on ((`pms`.`departmenttransfer`.`sid` = `pms`.`staff`.`id`)))
         join `pms`.`transfer2` on ((`pms`.`departmenttransfer`.`type` = `pms`.`transfer2`.`typeid`)));

