create definer = kanshan@`%` view changedepartment as
select `pms`.`staff`.`id`         AS `id`,
       `pms`.`staff`.`name`       AS `NAME`,
       `pms`.`staff`.`pid`        AS `pid`,
       `pms`.`staff`.`did`        AS `did`,
       `pms`.`post`.`pname`       AS `pname`,
       `pms`.`department`.`dname` AS `dname`
from ((`pms`.`staff` join `pms`.`post` on ((`pms`.`staff`.`pid` = `pms`.`post`.`pnum`)))
         join `pms`.`department` on ((`pms`.`staff`.`did` = `pms`.`department`.`dnum`)));

