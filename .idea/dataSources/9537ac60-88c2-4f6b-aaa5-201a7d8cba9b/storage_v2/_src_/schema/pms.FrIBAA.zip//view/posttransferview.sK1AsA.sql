create view posttransferview as
select `pms`.`posttransfer`.`sid`     AS `sid`,
       `pms`.`posttransfer`.`pid1`    AS `pid1`,
       `pms`.`posttransfer`.`tdate`   AS `tdate`,
       `pms`.`posttransfer`.`pid2`    AS `pid2`,
       `pms`.`posttransfer`.`reason`  AS `reason`,
       `pms`.`posttransfer`.`remarks` AS `remarks`,
       `pms`.`posttransfer`.`type`    AS `type`,
       `pms`.`posttransfer`.`pf`      AS `pf`,
       `pms`.`staff`.`name`           AS `name`,
       `pms`.`transfer1`.`postname`   AS `postname`
from ((`pms`.`posttransfer` join `pms`.`staff` on ((`pms`.`posttransfer`.`sid` = `pms`.`staff`.`id`)))
         join `pms`.`transfer1` on ((`pms`.`posttransfer`.`type` = `pms`.`transfer1`.`postid`)));

